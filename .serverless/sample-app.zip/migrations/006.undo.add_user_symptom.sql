DROP TABLE user_symptom CASCADE;
