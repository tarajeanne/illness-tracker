ALTER TABLE meals
ADD COLUMN name varchar;